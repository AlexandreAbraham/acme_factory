# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
from sklearn.datasets import fetch_covtype


data = fetch_covtype()
x = pd.DataFrame(data.data, columns=None)
y = pd.DataFrame(data.target, columns=['target'])

covertype_df = pd.concat([x, y], axis=1)

# Write recipe outputs
covertype = dataiku.Dataset("covertype")
covertype.write_with_schema(covertype_df)
