from lightning.regression import (AdaGradRegressor, CDRegressor, FistaRegressor,
                                  LinearSVR, SDCARegressor, SAGRegressor, SAGARegressor,
                                  SGDRegressor, SVRGRegressor)


class WrappedAdaGradRegressor(AdaGradRegressor):

    def fit(self, X, y):
        if hasattr(X, 'values'):
            X = X.values
        if hasattr(y, 'values'):
            y = y.values
        super(WrappedAdaGradRegressor, self).fit(X, y)
        if hasattr(self, 'coef_') and len(self.coef_.shape) == 2:
            self.coef_ = self.coef_[0]
        if not hasattr(self, 'intercept_'):
            self.intercept_ = 0.
        return self

    def predict(self, X):
        if hasattr(X, 'values'):
            X = X.values
        return super(WrappedAdaGradRegressor, self).predict(X)
        

class WrappedCDRegressor(CDRegressor):

    def fit(self, X, y):
        if hasattr(X, 'values'):
            X = X.values
        if hasattr(y, 'values'):
            y = y.values
        super(WrappedCDRegressor, self).fit(X, y)
        if hasattr(self, 'coef_') and len(self.coef_.shape) == 2:
            self.coef_ = self.coef_[0]
        if not hasattr(self, 'intercept_'):
            self.intercept_ = 0.
        return self

    def predict(self, X):
        if hasattr(X, 'values'):
            X = X.values
        return super(WrappedCDRegressor, self).predict(X)
        

class WrappedFistaRegressor(FistaRegressor):

    def fit(self, X, y):
        if hasattr(X, 'values'):
            X = X.values
        if hasattr(y, 'values'):
            y = y.values
        super(WrappedFistaRegressor, self).fit(X, y)
        if hasattr(self, 'coef_') and len(self.coef_.shape) == 2:
            self.coef_ = self.coef_[0]
        if not hasattr(self, 'intercept_'):
            self.intercept_ = 0.
        return self

    def predict(self, X):
        if hasattr(X, 'values'):
            X = X.values
        return super(WrappedFistaRegressor, self).predict(X)
        

class WrappedLinearSVR(LinearSVR):

    def fit(self, X, y):
        if hasattr(X, 'values'):
            X = X.values
        if hasattr(y, 'values'):
            y = y.values
        super(WrappedLinearSVR, self).fit(X, y)
        if hasattr(self, 'coef_') and len(self.coef_.shape) == 2:
            self.coef_ = self.coef_[0]
        if not hasattr(self, 'intercept_'):
            self.intercept_ = 0.
        return self

    def predict(self, X):
        if hasattr(X, 'values'):
            X = X.values
        return super(WrappedLinearSVR, self).predict(X)
        

class WrappedSDCARegressor(SDCARegressor):

    def fit(self, X, y):
        if hasattr(X, 'values'):
            X = X.values
        if hasattr(y, 'values'):
            y = y.values
        super(WrappedSDCARegressor, self).fit(X, y)
        if hasattr(self, 'coef_') and len(self.coef_.shape) == 2:
            self.coef_ = self.coef_[0]
        if not hasattr(self, 'intercept_'):
            self.intercept_ = 0.
        return self

    def predict(self, X):
        if hasattr(X, 'values'):
            X = X.values
        return super(WrappedSDCARegressor, self).predict(X)
        

class WrappedSAGRegressor(SAGRegressor):

    def fit(self, X, y):
        if hasattr(X, 'values'):
            X = X.values
        if hasattr(y, 'values'):
            y = y.values
        super(WrappedSAGRegressor, self).fit(X, y)
        if hasattr(self, 'coef_') and len(self.coef_.shape) == 2:
            self.coef_ = self.coef_[0]
        if not hasattr(self, 'intercept_'):
            self.intercept_ = 0.
        return self

    def predict(self, X):
        if hasattr(X, 'values'):
            X = X.values
        return super(WrappedSAGRegressor, self).predict(X)
        

class WrappedSAGARegressor(SAGARegressor):

    def fit(self, X, y):
        if hasattr(X, 'values'):
            X = X.values
        if hasattr(y, 'values'):
            y = y.values
        super(WrappedSAGARegressor, self).fit(X, y)
        if hasattr(self, 'coef_') and len(self.coef_.shape) == 2:
            self.coef_ = self.coef_[0]
        if not hasattr(self, 'intercept_'):
            self.intercept_ = 0.
        return self

    def predict(self, X):
        if hasattr(X, 'values'):
            X = X.values
        return super(WrappedSAGARegressor, self).predict(X)
        

class WrappedSGDRegressor(SGDRegressor):

    def fit(self, X, y):
        if hasattr(X, 'values'):
            X = X.values
        if hasattr(y, 'values'):
            y = y.values
        super(WrappedSGDRegressor, self).fit(X, y)
        if hasattr(self, 'coef_') and len(self.coef_.shape) == 2:
            self.coef_ = self.coef_[0]
        if not hasattr(self, 'intercept_'):
            self.intercept_ = 0.
        return self

    def predict(self, X):
        if hasattr(X, 'values'):
            X = X.values
        return super(WrappedSGDRegressor, self).predict(X)
        

class WrappedSVRGRegressor(SVRGRegressor):

    def fit(self, X, y):
        if hasattr(X, 'values'):
            X = X.values
        if hasattr(y, 'values'):
            y = y.values
        super(WrappedSVRGRegressor, self).fit(X, y)
        if hasattr(self, 'coef_') and len(self.coef_.shape) == 2:
            self.coef_ = self.coef_[0]
        if not hasattr(self, 'intercept_'):
            self.intercept_ = 0.
        return self

    def predict(self, X):
        if hasattr(X, 'values'):
            X = X.values
        return super(WrappedSVRGRegressor, self).predict(X)