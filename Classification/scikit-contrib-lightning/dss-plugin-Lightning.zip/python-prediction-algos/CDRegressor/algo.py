from dataiku.doctor.plugins.custom_prediction_algorithm import BaseCustomPredictionAlgorithm
from dku_utils import check_and_cast
from wrappers import WrappedCDRegressor as CDRegressor

class CustomPredictionAlgorithm(BaseCustomPredictionAlgorithm):    
    def __init__(self, prediction_type=None, params=None):    
        formatted_params = dict()

        formatted_params["C"] = check_and_cast("C", params["C"], float, True, None)
        formatted_params["alpha"] = check_and_cast("alpha", params["alpha"], float, True, None)
        formatted_params["loss"] = check_and_cast("loss", params["loss"], str, True, {'squared'})
        formatted_params["penalty"] = check_and_cast("penalty", params["penalty"], str, True, {'l1', 'l2', 'l1/l2', 'nnl1', 'nnl2'})
        formatted_params["max_iter"] = check_and_cast("max_iter", params["max_iter"], int, True, [1, None])
        formatted_params["tol"] = check_and_cast("tol", params["tol"], float, True, None)
        formatted_params["termination"] = check_and_cast("termination", params["termination"], str, True, {'violation_max', 'violation_sum'})
        formatted_params["shrinking"] = check_and_cast("shrinking", params["shrinking"], bool, True, {False, True})
        formatted_params["max_steps"] = check_and_cast("max_steps", params["max_steps"], int, True, [1, None])
        formatted_params["sigma"] = check_and_cast("sigma", params["sigma"], float, True, None)
        formatted_params["beta"] = check_and_cast("beta", params["beta"], float, True, None)
        formatted_params["debiasing"] = check_and_cast("debiasing", params["debiasing"], bool, True, {False, True})
        formatted_params["Cd"] = check_and_cast("Cd", params["Cd"], float, True, None)
        formatted_params["warm_debiasing"] = check_and_cast("warm_debiasing", params["warm_debiasing"], bool, True, {False, True})
        formatted_params["selection"] = check_and_cast("selection", params["selection"], str, True, {'cyclic', 'uniform'})
        formatted_params["permute"] = check_and_cast("permute", params["permute"], bool, True, {False, True})
        formatted_params["random_state"] = check_and_cast("random_state", params["random_state"], int, False, None)
        self.clf = CDRegressor(random_state = formatted_params.get('random_state', None))
        super(CustomPredictionAlgorithm, self).__init__(prediction_type, formatted_params)
    
    def get_clf(self):
        return self.clf
