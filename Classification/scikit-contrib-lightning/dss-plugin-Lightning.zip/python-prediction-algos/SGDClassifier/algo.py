from dataiku.doctor.plugins.custom_prediction_algorithm import BaseCustomPredictionAlgorithm
from lightning.classification import SGDClassifier
from dku_utils import check_and_cast

class CustomPredictionAlgorithm(BaseCustomPredictionAlgorithm):    
    def __init__(self, prediction_type=None, params=None):    
        formatted_params = dict()

        formatted_params["loss"] = check_and_cast("loss", params["loss"], str, True, {'log', 'squared_hinge', 'perceptron', 'hinge'})
        formatted_params["penalty"] = check_and_cast("penalty", params["penalty"], str, True, {'l1', 'l2', 'l1/l2'})
        formatted_params["multiclass"] = check_and_cast("multiclass", params["multiclass"], bool, True, {False, True})
        formatted_params["alpha"] = check_and_cast("alpha", params["alpha"], float, True, None)
        formatted_params["learning_rate"] = check_and_cast("learning_rate", params["learning_rate"], str, True, {'constant', 'invscaling', 'pegasos'})
        formatted_params["eta0"] = check_and_cast("eta0", params["eta0"], float, True, None)
        formatted_params["power_t"] = check_and_cast("power_t", params["power_t"], float, True, None)
        formatted_params["epsilon"] = check_and_cast("epsilon", params["epsilon"], float, True, None)
        formatted_params["fit_intercept"] = check_and_cast("fit_intercept", params["fit_intercept"], bool, True, {False, True})
        formatted_params["intercept_decay"] = check_and_cast("intercept_decay", params["intercept_decay"], float, True, None)
        formatted_params["max_iter"] = check_and_cast("max_iter", params["max_iter"], int, True, None)
        formatted_params["shuffle"] = check_and_cast("shuffle", params["shuffle"], bool, True, {False, True})
        formatted_params["random_state"] = check_and_cast("random_state", params["random_state"], int, False, None)
        self.clf = SGDClassifier(random_state = formatted_params.get('random_state', None))
        super(CustomPredictionAlgorithm, self).__init__(prediction_type, formatted_params)
    
    def get_clf(self):
        return self.clf
