from dataiku.doctor.plugins.custom_prediction_algorithm import BaseCustomPredictionAlgorithm
from dku_utils import check_and_cast
from wrappers import WrappedLinearSVR as LinearSVR


class CustomPredictionAlgorithm(BaseCustomPredictionAlgorithm):    
    def __init__(self, prediction_type=None, params=None):    
        formatted_params = dict()

        formatted_params["C"] = check_and_cast("C", params["C"], float, True, None)
        formatted_params["epsilon"] = check_and_cast("epsilon", params["epsilon"], float, True, None)
        formatted_params["loss"] = check_and_cast("loss", params["loss"], str, True, {'epsilon_insensitive', 'squared_epsilon_insensitive'})
        formatted_params["max_iter"] = check_and_cast("max_iter", params["max_iter"], int, True, [1, None])
        formatted_params["tol"] = check_and_cast("tol", params["tol"], float, True, None)
        formatted_params["fit_intercept"] = check_and_cast("fit_intercept", params["fit_intercept"], bool, True, {False, True})
        formatted_params["permute"] = check_and_cast("permute", params["permute"], bool, True, {False, True})
        formatted_params["random_state"] = check_and_cast("random_state", params["random_state"], int, False, None)
        self.clf = LinearSVR(random_state = formatted_params.get('random_state', None))
        super(CustomPredictionAlgorithm, self).__init__(prediction_type, formatted_params)
    
    def get_clf(self):
        return self.clf
