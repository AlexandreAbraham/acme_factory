from dataiku.doctor.plugins.custom_prediction_algorithm import BaseCustomPredictionAlgorithm
from dku_utils import check_and_cast
from wrappers import WrappedSAGARegressor as SAGARegressor


class CustomPredictionAlgorithm(BaseCustomPredictionAlgorithm):    
    def __init__(self, prediction_type=None, params=None):    
        formatted_params = dict()

        formatted_params["eta"] = check_and_cast("eta", params["eta"], str, True, {'line-search', 'auto'})
        formatted_params["alpha"] = check_and_cast("alpha", params["alpha"], float, True, None)
        formatted_params["beta"] = check_and_cast("beta", params["beta"], float, True, None)
        formatted_params["loss"] = check_and_cast("loss", params["loss"], str, True, None)
        formatted_params["max_iter"] = check_and_cast("max_iter", params["max_iter"], int, True, [1, None])
        formatted_params["n_inner"] = check_and_cast("n_inner", params["n_inner"], float, True, None)
        formatted_params["tol"] = check_and_cast("tol", params["tol"], float, True, None)
        formatted_params["random_state"] = check_and_cast("random_state", params["random_state"], int, False, None)
        self.clf = SAGARegressor(random_state = formatted_params.get('random_state', None))
        super(CustomPredictionAlgorithm, self).__init__(prediction_type, formatted_params)
    
    def get_clf(self):
        return self.clf
