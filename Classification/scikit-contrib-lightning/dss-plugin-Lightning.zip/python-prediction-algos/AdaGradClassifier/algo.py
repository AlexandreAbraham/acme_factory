from dataiku.doctor.plugins.custom_prediction_algorithm import BaseCustomPredictionAlgorithm
from lightning.classification import AdaGradClassifier
from dku_utils import check_and_cast

class CustomPredictionAlgorithm(BaseCustomPredictionAlgorithm):    
    def __init__(self, prediction_type=None, params=None):    
        formatted_params = dict()

        formatted_params["eta"] = check_and_cast("eta", params["eta"], float, True, None)
        formatted_params["alpha"] = check_and_cast("alpha", params["alpha"], float, True, None)
        formatted_params["l1_ratio"] = check_and_cast("l1_ratio", params["l1_ratio"], int, True, None)
        formatted_params["loss"] = check_and_cast("loss", params["loss"], str, True, {'modified_huber', 'squared_hinge', 'squared', 'perceptron', 'smooth_hinge', 'hinge', 'log'})
        formatted_params["gamma"] = check_and_cast("gamma", params["gamma"], float, True, None)
        formatted_params["n_iter"] = check_and_cast("n_iter", params["n_iter"], int, True, None)
        formatted_params["shuffle"] = check_and_cast("shuffle", params["shuffle"], bool, True, {False, True})
        formatted_params["random_state"] = check_and_cast("random_state", params["random_state"], int, False, None)
        self.clf = AdaGradClassifier(random_state = formatted_params.get('random_state', None))
        super(CustomPredictionAlgorithm, self).__init__(prediction_type, formatted_params)
    
    def get_clf(self):
        return self.clf
