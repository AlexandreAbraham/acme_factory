from dataiku.doctor.plugins.custom_prediction_algorithm import BaseCustomPredictionAlgorithm
from dku_utils import check_and_cast
from wrappers import WrappedFistaRegressor as FistaRegressor


class CustomPredictionAlgorithm(BaseCustomPredictionAlgorithm):    
    def __init__(self, prediction_type=None, params=None):    
        formatted_params = dict()

        formatted_params["C"] = check_and_cast("C", params["C"], float, True, None)
        formatted_params["alpha"] = check_and_cast("alpha", params["alpha"], float, True, None)
        formatted_params["penalty"] = check_and_cast("penalty", params["penalty"], str, True, {'l1/l2', 'tv1d', 'l1', 'simplex', 'l2'})
        formatted_params["max_iter"] = check_and_cast("max_iter", params["max_iter"], int, True, [1, None])
        formatted_params["max_steps"] = check_and_cast("max_steps", params["max_steps"], int, True, [1, None])
        formatted_params["eta"] = check_and_cast("eta", params["eta"], float, True, None)
        formatted_params["sigma"] = check_and_cast("sigma", params["sigma"], float, True, None)
        self.clf = FistaRegressor()
        super(CustomPredictionAlgorithm, self).__init__(prediction_type, formatted_params)
    
    def get_clf(self):
        return self.clf
