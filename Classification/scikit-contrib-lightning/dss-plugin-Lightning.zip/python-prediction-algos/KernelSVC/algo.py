from dataiku.doctor.plugins.custom_prediction_algorithm import BaseCustomPredictionAlgorithm
from lightning.classification import KernelSVC
from dku_utils import check_and_cast

class CustomPredictionAlgorithm(BaseCustomPredictionAlgorithm):    
    def __init__(self, prediction_type=None, params=None):    
        formatted_params = dict()

        formatted_params["alpha"] = check_and_cast("alpha", params["alpha"], float, True, None)
        formatted_params["solver"] = check_and_cast("solver", params["solver"], str, True, {'dense', 'cg'})
        formatted_params["max_iter"] = check_and_cast("max_iter", params["max_iter"], int, True, [1, None])
        formatted_params["tol"] = check_and_cast("tol", params["tol"], float, True, None)
        formatted_params["kernel"] = check_and_cast("kernel", params["kernel"], str, True, {'poly', 'rbf', 'linear', 'sigmoid', 'cosine'})
        formatted_params["gamma"] = check_and_cast("gamma", params["gamma"], float, True, None)
        formatted_params["coef0"] = check_and_cast("coef0", params["coef0"], int, True, None)
        formatted_params["degree"] = check_and_cast("degree", params["degree"], int, True, None)
        formatted_params["random_state"] = check_and_cast("random_state", params["random_state"], int, False, None)
        self.clf = KernelSVC(random_state = formatted_params.get('random_state', None))
        super(CustomPredictionAlgorithm, self).__init__(prediction_type, formatted_params)
    
    def get_clf(self):
        return self.clf
