from dataiku.doctor.plugins.custom_prediction_algorithm import BaseCustomPredictionAlgorithm
from lightning.regression import SDCARegressor
from dku_utils import check_and_cast
from wrappers import WrappedSDCARegressor as SDCARegressor


class CustomPredictionAlgorithm(BaseCustomPredictionAlgorithm):    
    def __init__(self, prediction_type=None, params=None):    
        formatted_params = dict()

        formatted_params["alpha"] = check_and_cast("alpha", params["alpha"], float, True, None)
        formatted_params["l1_ratio"] = check_and_cast("l1_ratio", params["l1_ratio"], float, True, [0, 1])
        formatted_params["loss"] = check_and_cast("loss", params["loss"], str, True, {'squared', 'absolute'})
        formatted_params["max_iter"] = check_and_cast("max_iter", params["max_iter"], int, True, [1, None])
        formatted_params["tol"] = check_and_cast("tol", params["tol"], float, True, None)
        formatted_params["random_state"] = check_and_cast("random_state", params["random_state"], int, False, None)
        self.clf = SDCARegressor(random_state = formatted_params.get('random_state', None))
        super(CustomPredictionAlgorithm, self).__init__(prediction_type, formatted_params)
    
    def get_clf(self):
        return self.clf
