import os, sys
import time
import copy
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import torch, torch.nn as nn
import torch.nn.functional as F
from sklearn.model_selection import train_test_split
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.preprocessing import LabelEncoder

from .arch import DenseBlock
from .nn_utils import entmax15, entmoid15
from .utils import iterate_minibatches, process_in_chunks, check_numpy


class Reduce(nn.Module):
    def __init__(self, num_classes):
        super().__init__()
        self.num_classes = num_classes

    def forward(self, x):
        if self.num_classes is None:
            # Regression
            return x[..., 0].mean(dim=-1)
        else:
            return x[..., :self.num_classes].mean(dim=-2)


class NodeClassifier(nn.Module, BaseEstimator):
    """Neural Oblivious Decision Ensembles
    
    A GBDT inspired neural network architecture.
    
    Params
    ------
    layer_size:
        Size of the intermediate representation
        
    num_layers:
        Number of layers in the ODST module
        
    tree_dim:
        Dimension of trees in the ODST module
        
    depth:
        Depth of trees in the ODST module
    """

    def __init__(self, layer_size=64, num_layers=4, depth=6, validation_size=None, max_iter=30, val_size=.1, device='cpu'):
        super().__init__()
        self.layer_size = layer_size
        self.num_layers = num_layers
        self.depth = depth
        self.validation_size = validation_size
        self.device = device
        self.max_iter = max_iter
        self.val_size = val_size

    def fit(self, X, y):

        X = X.astype(np.float32)
        if hasattr(X, 'values'):
            X = X.values
        if hasattr(y, 'values'):
            y = y.values
            
        self.encoder = LabelEncoder()
        self.encoder.fit(y)
        y = self.encoder.transform(y)
        self.classes_ = self.encoder.classes_
        
        if self.val_size:
            X, X_val, y, y_val = train_test_split(X, y, test_size=self.val_size, stratify=y)
            X_val = torch.as_tensor(X_val)
            y_val = torch.as_tensor(y_val)

        num_classes = np.unique(y).shape[0]
        print('num_classes', num_classes)
        model = nn.Sequential(
            DenseBlock(
                X.shape[1], self.layer_size, num_layers=self.num_layers,
                tree_dim=num_classes + 1, depth=self.depth, flatten_output=False,
                choice_function=entmax15, bin_function=entmoid15),
            Reduce(num_classes),
        ).to(self.device)
        self.model = model

        # trigger data-aware init
        with torch.no_grad():
            res = model(torch.as_tensor(X[:1000], device=self.device))

        from qhoptim.pyt import QHAdam
        optimizer_params = { 'nus':(0.7, 1.0), 'betas':(0.95, 0.998) }

        loss_function = F.cross_entropy
        opt = QHAdam(list(model.parameters()), **optimizer_params)

        best_loss = None
        best_state = None
        
        for batch in iterate_minibatches(
            X, y, batch_size=512, shuffle=True, epochs=self.max_iter):

            x_batch, y_batch = batch
            x_batch = torch.as_tensor(x_batch, device=self.device)
            y_batch = torch.as_tensor(y_batch, device=self.device)

            model.train()
            opt.zero_grad()
            loss = loss_function(self.model(x_batch), y_batch).mean()
            loss.backward()
            opt.step()
            
            if self.val_size is not None:
                loss = loss_function(self.model(X_val), y_val).mean()
            
            if best_loss is not None and loss - best_loss < 1e-8:
                best_loss = loss
                best_state = copy.copy(model.state_dict())

        if best_state:
            self.model.load_state_dict(best_state)
                
        with torch.no_grad():
            logits = process_in_chunks(self.model, torch.as_tensor(X, device=self.device), batch_size=4096)
            logits = check_numpy(logits)
        print(np.unique(np.argmax(logits, axis=1), return_counts=True))

    def predict(self, X):
        logits = self.predict_proba(X)
        return pd.Series(self.encoder.inverse_transform(np.argmax(logits, axis=1)))
    
    def predict_proba(self, X):
        if hasattr(X, 'values'):
            X = X.values
        X = X.astype(np.float32)
        X = torch.as_tensor(X, device=self.device)
        self.model.train(False)
        with torch.no_grad():
            logits = process_in_chunks(self.model, X, batch_size=4096)
            logits = check_numpy(logits)
        return logits
    
    
class NodeRegressor(nn.Module, BaseEstimator):
    """Neural Oblivious Decision Ensembles
    
    A GBDT inspired neural network architecture.
    
    Params
    ------
    layer_size:
        Size of the intermediate representation
        
    num_layers:
        Number of layers in the ODST module
        
    tree_dim:
        Dimension of trees in the ODST module
        
    depth:
        Depth of trees in the ODST module
    """

    def __init__(self, layer_size=64, num_layers=4, tree_dim=4, depth=6, validation_size=None, max_iter=30, val_size=.1, device='cpu'):
        super().__init__()
        self.layer_size = layer_size
        self.num_layers = num_layers
        self.tree_dim = tree_dim
        self.depth = depth
        self.validation_size = validation_size
        self.device = device
        self.max_iter = max_iter
        self.val_size = val_size

    def fit(self, X, y):

        X = X.astype(np.float32)
        y = y.astype(np.float32)
        if hasattr(X, 'values'):
            X = X.values
        if hasattr(y, 'values'):
            y = y.values
        
        if self.val_size:
            X, X_val, y, y_val = train_test_split(X, y, test_size=self.val_size)
            X_val = torch.as_tensor(X_val)
            y_val = torch.as_tensor(y_val)

        model = nn.Sequential(
            DenseBlock(
                X.shape[1], self.layer_size, num_layers=self.num_layers,
                tree_dim=self.tree_dim, depth=self.depth, flatten_output=False,
                choice_function=entmax15, bin_function=entmoid15),
            Reduce(None),
        ).to(self.device)
        self.model = model

        # trigger data-aware init
        with torch.no_grad():
            res = model(torch.as_tensor(X[:1000], device=self.device))

        from qhoptim.pyt import QHAdam
        optimizer_params = { 'nus':(0.7, 1.0), 'betas':(0.95, 0.998) }

        loss_function = F.mse_loss
        opt = QHAdam(list(model.parameters()), **optimizer_params)

        best_loss = None
        best_state = None
        
        for batch in iterate_minibatches(
            X, y, batch_size=512, shuffle=True, epochs=self.max_iter):

            x_batch, y_batch = batch
            x_batch = torch.as_tensor(x_batch, device=self.device)
            y_batch = torch.as_tensor(y_batch, device=self.device)

            model.train()
            opt.zero_grad()
            loss = loss_function(self.model(x_batch), y_batch).mean()
            loss.backward()
            opt.step()
            
            if self.val_size is not None:
                loss = loss_function(self.model(X_val), y_val).mean()
            
            if best_loss is not None and loss - best_loss < 1e-8:
                best_loss = loss
                best_state = copy.copy(model.state_dict())

        if best_state:
            self.model.load_state_dict(best_state)
                
        with torch.no_grad():
            logits = process_in_chunks(self.model, torch.as_tensor(X, device=self.device), batch_size=4096)
            logits = check_numpy(logits)

    def predict(self, X):
        if hasattr(X, 'values'):
            X = X.values
        X = X.astype(np.float32)
        X = torch.as_tensor(X, device=self.device)
        self.model.train(False)
        with torch.no_grad():
            logits = process_in_chunks(self.model, X, batch_size=4096)
            logits = check_numpy(logits)
        return logits
