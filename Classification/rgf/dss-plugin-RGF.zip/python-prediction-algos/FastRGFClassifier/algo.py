from dataiku.doctor.plugins.custom_prediction_algorithm import BaseCustomPredictionAlgorithm
from rgf.sklearn import FastRGFClassifier
from dku_utils import check_and_cast

class CustomPredictionAlgorithm(BaseCustomPredictionAlgorithm):    
    def __init__(self, prediction_type=None, params=None):    
        formatted_params = dict()

        formatted_params["n_estimators"] = check_and_cast("n_estimators", params["n_estimators"], int, True, [1, None])
        formatted_params["max_depth"] = check_and_cast("max_depth", params["max_depth"], int, True, [1, None])
        formatted_params["max_leaf"] = check_and_cast("max_leaf", params["max_leaf"], int, True, [1, None])
        formatted_params["tree_gain_ratio"] = check_and_cast("tree_gain_ratio", params["tree_gain_ratio"], float, True, None)
        formatted_params["min_samples_leaf"] = check_and_cast("min_samples_leaf", params["min_samples_leaf"], int, True, [1, None])
        formatted_params["loss"] = check_and_cast("loss", params["loss"], str, True, {'Expo', 'LS', 'Log'})
        formatted_params["l1"] = check_and_cast("l1", params["l1"], float, True, None)
        formatted_params["l2"] = check_and_cast("l2", params["l2"], float, True, None)
        formatted_params["opt_algorithm"] = check_and_cast("opt_algorithm", params["opt_algorithm"], str, True, {'rgf', 'epsilon-greedy'})
        formatted_params["learning_rate"] = check_and_cast("learning_rate", params["learning_rate"], float, True, None)
        formatted_params["max_bin"] = check_and_cast("max_bin", params["max_bin"], int, True, None)
        formatted_params["min_child_weight"] = check_and_cast("min_child_weight", params["min_child_weight"], float, True, None)
        formatted_params["data_l2"] = check_and_cast("data_l2", params["data_l2"], float, True, None)
        formatted_params["sparse_max_features"] = check_and_cast("sparse_max_features", params["sparse_max_features"], int, True, None)
        formatted_params["sparse_min_occurences"] = check_and_cast("sparse_min_occurences", params["sparse_min_occurences"], int, True, None)
        formatted_params["calc_prob"] = check_and_cast("calc_prob", params["calc_prob"], str, True, {'sigmoid', 'softmax'})
        self.clf = FastRGFClassifier()
        super(CustomPredictionAlgorithm, self).__init__(prediction_type, formatted_params)
    
    def get_clf(self):
        return self.clf
