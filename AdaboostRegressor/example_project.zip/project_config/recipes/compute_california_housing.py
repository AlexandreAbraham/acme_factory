# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
from sklearn.datasets import fetch_california_housing

california_housing_df = fetch_california_housing()
data1 = pd.DataFrame(data= np.c_[california_housing_df['data'], california_housing_df['target']],
                     columns= california_housing_df['feature_names'] + ['target'])


# Write recipe outputs
california_housing = dataiku.Dataset("california_housing")
california_housing.write_with_schema(data1)

